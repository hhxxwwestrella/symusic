#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Parallel pre-tokenizer for pre-windowed segments (Option B), FAST path.

Key changes vs previous version:
- Build per-file cache once (Mido MidiFile, MidiDict, downbeats).
- Slice at MidiDict level (no PrettyMIDI write/read, no deepcopy).
- Apply transpose during slicing.
- Tokenize directly from MidiDict (no mido→dict per window).
"""

import argparse
import atexit
import cProfile
import hashlib
import io
import json
import logging
import math
import os
import pstats
import sys
import tarfile
import traceback
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Tuple, Optional

import mido
import numpy as np
import pretty_midi
from tqdm import tqdm
from multiprocessing import Pool, current_process
from functools import partial

# Aria tokenizer
from ariautils.tokenizer import AbsTokenizer
from ariautils.midi import MidiDict

from file_cache import FileCache, build_file_cache
from tick_ms_convert import TickMsConverter

# -----------------------------
# Logging
# -----------------------------

def setup_logging(level: str, log_file: Optional[Path] = None, process_tag: Optional[str] = None):
    root = logging.getLogger()
    if root.handlers:
        for h in list(root.handlers):
            root.removeHandler(h)
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    fmt = f"%(asctime)s [%(levelname)s] [{process_tag or '%(processName)s'}:%(process)d] %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    sh = logging.StreamHandler(sys.stderr)
    sh.setFormatter(logging.Formatter(fmt=fmt, datefmt=datefmt))
    root.addHandler(sh)

    if log_file is not None:
        fh = logging.FileHandler(log_file, mode="a", encoding="utf-8")
        fh.setFormatter(logging.Formatter(fmt=fmt, datefmt=datefmt))
        root.addHandler(fh)

def log_exception(msg: str, **ctx):
    logging.error("%s | ctx=%s\n%s", msg, json.dumps(ctx, ensure_ascii=False), traceback.format_exc())

# -----------------------------
# Helpers
# -----------------------------

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def tokenizer_config_hash(tok: AbsTokenizer) -> str:
    cfg = {"class": tok.__class__.__name__, "vocab_size": getattr(tok, "vocab_size", None)}
    try:
        if hasattr(tok, "config") and isinstance(tok.config, dict):
            cfg["config"] = tok.config
        elif hasattr(tok, "to_json"):
            cfg["json"] = tok.to_json()
    except Exception:
        log_exception("Tokenizer config serialization failed")
    return sha256_bytes(json.dumps(cfg, sort_keys=True).encode("utf-8"))

def pad1(seq: List[int], pad_id: int = 0) -> Tuple[np.ndarray, np.ndarray]:
    arr = np.asarray(seq, dtype=np.int64)
    attn = np.ones_like(arr, dtype=np.int64)
    return arr, attn

def stable_uid(path: Path, i_bar: int, k_bars: int, phrase_bars: int, transpose: int) -> str:
    base = f"{path.as_posix()}|{i_bar}|{k_bars}|{phrase_bars}|{transpose}"
    return sha256_bytes(base.encode("utf-8"))

def find_midis(root: Path) -> List[Path]:
    exts = ["*.mid", "*.midi", "*.MID", "*.MIDI"]
    files = []
    for pat in exts:
        files.extend(root.rglob(pat))
    return sorted(set(files))

def _ensure_md_empty_like(md: MidiDict) -> MidiDict:
    # Construct a minimal empty MidiDict preserving ticks_per_beat & metadata if available
    base = {
        "meta_msgs": [],
        "tempo_msgs": [],
        "pedal_msgs": [],
        "instrument_msgs": getattr(md, "instrument_msgs", []),
        "note_msgs": [],
        "ticks_per_beat": getattr(md, "ticks_per_beat", 480),
        "metadata": dict(getattr(md, "metadata", {})),
    }
    return MidiDict.from_msg_dict(base)

def _tempo_at_tick(tempo_msgs: list[dict], tick: int) -> int:
    """Return active tempo (µs/beat) at given tick."""
    if not tempo_msgs:
        return 500_000  # 120 BPM default
    tempo = 500_000
    for tm in sorted(tempo_msgs, key=lambda m: m["tick"]):
        if tm["tick"] <= tick:
            tempo = tm["data"]
        else:
            break
    return tempo

def _ms_to_tick(md: MidiDict, target_ms: float) -> int:
    """
    Convert absolute milliseconds from piece start -> tick using the md's tempo map.
    """
    tpb = md.ticks_per_beat
    tms = sorted(md.tempo_msgs, key=lambda m: m["tick"])
    if not tms or tms[0]["tick"] != 0:
        # Ensure a tempo at tick 0
        tms = [{"type": "tempo", "data": 500_000, "tick": 0}] + tms

    remaining_ms = float(target_ms)
    curr_tick = tms[0]["tick"]
    for i in range(len(tms) - 1):
        seg_start_tick = tms[i]["tick"]
        seg_end_tick = tms[i + 1]["tick"]
        tempo = tms[i]["data"]  # µs/beat
        ms_per_tick = tempo / 1000.0 / tpb
        seg_ticks = seg_end_tick - seg_start_tick
        seg_ms = seg_ticks * ms_per_tick
        if remaining_ms < seg_ms:
            return seg_start_tick + int(round(remaining_ms / ms_per_tick))
        remaining_ms -= seg_ms
        curr_tick = seg_end_tick

    # After last tempo change
    last_tempo = tms[-1]["data"]
    ms_per_tick = last_tempo / 1000.0 / tpb
    return curr_tick + int(round(remaining_ms / ms_per_tick))

def slice_mididict_vec(
    md_full: "MidiDict",
    start_s: float,
    end_s: float,
    tmc: Optional[TickMsConverter] = None,
) -> "MidiDict":
    """
    Slice MidiDict into [start_s, end_s) seconds with:
      • vectorized tick↔ms via TickMsConverter,
      • no deepcopy, channel+instrument preserved,
      • tempo map rebased to tick 0.

    Returns a new MidiDict with:
      - ticks_per_beat = md_full.ticks_per_beat
      - tempo_msgs = tempo at 0 plus changes inside window
      - instrument_msgs = passed through from md_full
      - note_msgs = clipped to window, re-based to 0
    """
    # Prepare output container (no deep copies)
    def _empty_like(md: "MidiDict") -> "MidiDict":
        base = {
            "meta_msgs": [],
            "tempo_msgs": [],
            "pedal_msgs": [],
            "instrument_msgs": getattr(md, "instrument_msgs", []),
            "note_msgs": [],
            "ticks_per_beat": getattr(md, "ticks_per_beat", 480),
            "metadata": dict(getattr(md, "metadata", {})),
        }
        return md.__class__.from_msg_dict(base)

    out = _empty_like(md_full)
    if not tmc:
        tmc = TickMsConverter.from_mididict(md_full)

    start_ms = float(start_s) * 1000.0
    end_ms   = float(end_s)   * 1000.0
    if end_ms <= start_ms:
        # Provide a valid tempo at tick 0, empty notes
        out.tempo_msgs = [{"type": "tempo", "data": tmc.tempo_at_tick(0), "tick": 0}]
        return out

    # Convert window boundaries to absolute ticks (rounded)
    start_tick_abs = int(tmc.ms_to_tick(start_ms))
    end_tick_abs   = int(tmc.ms_to_tick(end_ms))
    if end_tick_abs <= start_tick_abs:
        out.tempo_msgs = [{"type": "tempo", "data": tmc.tempo_at_tick(start_tick_abs), "tick": 0}]
        return out

    # Tempo map for the slice (rebased)
    out.tempo_msgs = tmc.slice_tempo_msgs(start_tick_abs, end_tick_abs)

    # -------- notes (vectorized) --------
    # Collect pitched notes (skip drums on channel 9). Keep channels for instrument mapping.
    notes = [n for n in md_full.note_msgs if n.get("type") == "note" and n["channel"] != 9]
    if not notes:
        return out

    start_ticks = np.fromiter((n["data"]["start"] for n in notes), dtype=np.int64)
    end_ticks   = np.fromiter((n["data"]["end"]   for n in notes), dtype=np.int64)
    pitches     = np.fromiter((n["data"]["pitch"] for n in notes), dtype=np.int16)
    velocities  = np.fromiter((n["data"]["velocity"] for n in notes), dtype=np.int16)
    channels    = np.fromiter((n["channel"] for n in notes), dtype=np.int16)

    # Convert to ms in bulk
    starts_ms = tmc.ticks_to_ms(start_ticks)
    ends_ms   = tmc.ticks_to_ms(end_ticks)

    # Overlap with [start_ms, end_ms)
    ov = (ends_ms > start_ms) & (starts_ms < end_ms)
    if not np.any(ov):
        return out

    # Clip and map back to ticks (absolute) using the same converter
    s_ms_clip = np.maximum(starts_ms[ov], int(round(start_ms)))
    e_ms_clip = np.minimum(ends_ms[ov],   int(round(end_ms)))

    s_abs = tmc.ms_to_tick(s_ms_clip).astype(np.int64)
    e_abs = tmc.ms_to_tick(e_ms_clip).astype(np.int64)

    # Rebase to slice start
    s_rel = s_abs - start_tick_abs
    e_rel = e_abs - start_tick_abs

    p = pitches[ov].astype(np.int16)

    v = velocities[ov].astype(np.int16)
    c = channels[ov].astype(np.int16)

    # Assemble NoteMessages (sorted by onset tick for downstream tokenizer)
    order = np.argsort(s_rel, kind="stable")
    out.note_msgs = [
        {
            "type": "note",
            "channel": int(c[i]),
            "tick": int(s_rel[i]),
            "data": {
                "pitch": int(p[i]),
                "start": int(s_rel[i]),
                "end": int(e_rel[i]),
                "velocity": int(v[i]),
            },
        }
        for i in order
    ]

    return out

def has_pitched_notes_md(md: MidiDict) -> bool:
    try:
        return any(msg for msg in md.note_msgs if msg.get("type") == "note" and msg["channel"] != 9)
    except Exception:
        log_exception("has_pitched_notes_md failed")
        return False

# -----------------------------
# Sharded writer (main process)
# -----------------------------

@dataclass
class ShardWriter:
    out_dir: Path
    shard_size: int = 5000
    compress: Optional[str] = "gz"

    def __post_init__(self):
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.shard_idx = 0
        self.count_in_shard = 0
        self.tar = None
        self._open_new_shard()

    def _shard_path(self) -> Path:
        suffix = ".tar.gz" if self.compress == "gz" else ".tar"
        return self.out_dir / f"tokens-{self.shard_idx:05d}{suffix}"

    def _open_new_shard(self):
        if self.tar is not None:
            try:
                self.tar.close()
            except Exception:
                log_exception("Tar close failed", shard=self.shard_idx)
        path = self._shard_path()
        mode = "w:gz" if self.compress == "gz" else "w"
        try:
            self.tar = tarfile.open(path, mode)
            logging.info("Opened shard %s", path)
        except Exception:
            log_exception("Opening shard failed", path=str(path))
            raise
        self.count_in_shard = 0

    def add_item(self, uid: str, phrase_ids: np.ndarray, phrase_attn: np.ndarray,
                 ctx_ids: np.ndarray, ctx_attn: np.ndarray, meta: dict):
        if self.count_in_shard >= self.shard_size:
            self.shard_idx += 1
            self._open_new_shard()

        try:
            def add_np(name: str, arr: np.ndarray):
                buf = io.BytesIO()
                np.save(buf, arr)
                data = buf.getvalue()
                ti = tarfile.TarInfo(name=name)
                ti.size = len(data)
                self.tar.addfile(ti, fileobj=io.BytesIO(data))

            def add_json(name: str, obj: dict):
                data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
                ti = tarfile.TarInfo(name=name)
                ti.size = len(data)
                self.tar.addfile(ti, fileobj=io.BytesIO(data))

            add_np(f"{uid}.phrase_ids.npy", phrase_ids)
            add_np(f"{uid}.phrase_attn.npy", phrase_attn)
            add_np(f"{uid}.context_ids.npy", ctx_ids)
            add_np(f"{uid}.context_attn.npy", ctx_attn)
            add_json(f"{uid}.meta.json", meta)

            self.count_in_shard += 1
        except Exception:
            log_exception("Writing item to shard failed", uid=uid, shard=self.shard_idx)

    def close(self):
        if self.tar is not None:
            try:
                self.tar.close()
                logging.info("Closed shard %s", self._shard_path())
            except Exception:
                log_exception("Closing shard failed", shard=self.shard_idx)
            self.tar = None

# -----------------------------
# Worker (child process)
# -----------------------------

_WORKER_TOK = None
_WORKER_TOK_HASH = None
_WORKER_FILE_CACHE = {}   # ### NEW: path -> FileCache ###

def _worker_init(log_level: str, log_file: Optional[str]):
    tag = f"worker:{current_process().name}"
    setup_logging(log_level, Path(log_file) if log_file else None, process_tag=tag)
    logging.info("Worker initializing tokenizer")
    try:
        global _WORKER_TOK, _WORKER_TOK_HASH
        _WORKER_TOK = AbsTokenizer()
        _WORKER_TOK_HASH = tokenizer_config_hash(_WORKER_TOK)
        logging.info("Worker tokenizer ready (hash=%s)", _WORKER_TOK_HASH)
    except Exception:
        log_exception("Worker failed to initialize tokenizer")
        raise

def _get_file_cache(path_str: str) -> FileCache:
    fc = _WORKER_FILE_CACHE.get(path_str)
    if fc is None:
        fc = build_file_cache(path_str)
        _WORKER_FILE_CACHE[path_str] = fc
    return fc

def _encode_mididict(tok: AbsTokenizer, md: MidiDict) -> List[int]:
    # Tokenize directly from MidiDict; no PrettyMIDI/Mido round-trip
    toks = tok.tokenize(midi_dict=md, remove_preceding_silence=True)
    ids = tok.encode(toks)
    return ids

def _process_one_file(
    path_str: str,
    k_bars: int,
    phrase_bars: int,
    stride_bars: int,
    max_pairs_per_file: Optional[int],
) -> Tuple[str, List[Tuple[str, np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict]], List[str]]:
    """
    Returns:
      (path_str, items, errors)
      - items: [(uid, phr_ids, phr_attn, ctx_ids, ctx_attn, meta), ...]
      - errors: list of textual error summaries (logged in worker already)
    """
    errors: List[str] = []
    items: List[Tuple[str, np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict]] = []
    path = Path(path_str)

    # Build/get per-file cache
    try:
        fc = _get_file_cache(path_str)
    except Exception:
        msg = "Failed to build file cache"
        log_exception(msg, path=path_str)
        errors.append(msg)
        return path_str, items, errors

    downbeats = fc.downbeats
    if len(downbeats) < (k_bars + phrase_bars + 1):
        logging.debug("Too few bars; skipping file %s", path_str)
        return path_str, items, errors

    valid_i = list(range(k_bars, len(downbeats) - phrase_bars, max(1, stride_bars)))
    if max_pairs_per_file and len(valid_i) > max_pairs_per_file:
        rng = np.random.RandomState(17)
        try:
            valid_i = list(rng.choice(valid_i, size=max_pairs_per_file, replace=False))
        except Exception:
            log_exception("rng choice failed", path=path_str, n=len(valid_i), k=max_pairs_per_file)

    for i in valid_i:
        ctx_st, ctx_en = float(downbeats[i - k_bars]), float(downbeats[i])
        phr_st, phr_en = float(downbeats[i]), float(downbeats[i + phrase_bars])

        # Slice at MidiDict level (FAST)
        try:
            # XXX: Add TickMsConverter to these calls!
            md_ctx = slice_mididict_vec(fc.md_full, ctx_st, ctx_en, fc.tick_ms)
            md_phr = slice_mididict_vec(fc.md_full, phr_st, phr_en, fc.tick_ms)

            if not (has_pitched_notes_md(md_ctx) and has_pitched_notes_md(md_phr)):
                logging.debug("Empty/drum-only window; skipping %s i=%d", path_str, i)
                continue

            ctx_ids = _encode_mididict(_WORKER_TOK, md_ctx)
            phr_ids = _encode_mididict(_WORKER_TOK, md_phr)
            if len(ctx_ids) == 0 or len(phr_ids) == 0:
                logging.warning("Tokenizer produced empty ids; skipping window %s i=%d", path_str, i)
                continue

            phr_ids_arr, phr_attn_arr = pad1(phr_ids)
            ctx_ids_arr, ctx_attn_arr = pad1(ctx_ids)

            uid = stable_uid(path, i, k_bars, phrase_bars, 0) # last argument is 0 transpose
            meta = {
                "src_path": str(path),
                "start_bar": int(i),
                "k_bars": int(k_bars),
                "phrase_bars": int(phrase_bars),
                "stride_bars": int(stride_bars),
                "transpose": 0,
                "tokenizer_hash": _WORKER_TOK_HASH,
                "ctx_tokens": int(ctx_ids_arr.shape[0]),
                "phr_tokens": int(phr_ids_arr.shape[0]),
            }
            items.append((uid, phr_ids_arr, phr_attn_arr, ctx_ids_arr, ctx_attn_arr, meta))

        except Exception:
            log_exception("Failed to process window", path=path_str, i=i)
            errors.append("process window failed")
            continue

    return path_str, items, errors

def maybe_enable_profiler(enable: bool, tag: str = "worker"):
    if not enable:
        class Nop:
            def __enter__(self): return None
            def __exit__(self, *a): return False
        return Nop()
    pf = cProfile.Profile()
    pf.enable()
    def _dump():
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        out = f"profile-{tag}-pid{os.getpid()}-{ts}.prof"
        pf.dump_stats(out)
        print(f"[prof] wrote {out}")
    atexit.register(_dump)
    class Ctx:
        def __enter__(self): return pf
        def __exit__(self, *a): pf.disable(); _dump()
    return Ctx()

def process_one_file(*args, **kwargs):
    profile = kwargs['yes_do_profile_for_optimization']
    with maybe_enable_profiler(profile, tag="tokenize"):
        kwargs2 = kwargs.copy()
        del kwargs2['yes_do_profile_for_optimization']
        return _process_one_file(*args, **kwargs2)

# -----------------------------
# Orchestrator (main)
# -----------------------------

def main():
    ap = argparse.ArgumentParser("Parallel pre-tokenize Option B into tar shards (FAST)")
    ap.add_argument("--midi-root", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--k-bars", type=int, default=12)
    ap.add_argument("--phrase-bars", type=int, default=4)
    ap.add_argument("--stride-bars", type=int, default=1)
    ap.add_argument("--max-files", type=int, default=None)
    ap.add_argument("--max-pairs-per-file", type=int, default=None)
    ap.add_argument("--shard-size", type=int, default=5000, help="items per tar shard")
    ap.add_argument("--compress", choices=["gz", "none"], default="gz")
    ap.add_argument("--num-workers", type=int, default=os.cpu_count() or 8)
    ap.add_argument("--chunksize", type=int, default=4, help="files per task (imap_unordered chunksize)")
    ap.add_argument("--log-level", default="INFO", help="DEBUG, INFO, WARNING, ERROR")
    ap.add_argument("--log-file", type=Path, default=None)
    ap.add_argument("--strict", action="store_true", help="Abort on first worker error")
    ap.add_argument("--profile", action="store_true", help="Dump cProfile per worker")
    args = ap.parse_args()

    setup_logging(args.log_level, args.log_file, process_tag="main")

    logging.info("Config: midi_root=%s out_dir=%s k=%d phrase=%d stride=%d num_workers=%d chunksize=%d",
                 args.midi_root, args.out_dir, args.k_bars, args.phrase_bars, args.stride_bars,
                 args.num_workers, args.chunksize)

    try:
        midi_files = find_midis(args.midi_root)
    except Exception:
        log_exception("Failed to enumerate MIDI files", root=str(args.midi_root))
        raise
    if args.max_files:
        midi_files = midi_files[: args.max_files]
    logging.info("Found %d MIDI files", len(midi_files))

    writer = ShardWriter(args.out_dir, shard_size=args.shard_size, compress=("gz" if args.compress == "gz" else None))

    if args.profile:
        logging.info("enabling performance profiling")

    worker_fn = partial(
        process_one_file,
        k_bars=args.k_bars,
        phrase_bars=args.phrase_bars,
        stride_bars=args.stride_bars,
        max_pairs_per_file=args.max_pairs_per_file,
        yes_do_profile_for_optimization=args.profile,
    )

    n_files = len(midi_files)
    n_items = 0
    n_err_files = 0

    try:
        with Pool(processes=args.num_workers, initializer=_worker_init,
                  initargs=(args.log_level, str(args.log_file) if args.log_file else None)) as pool, \
             tqdm(total=n_files, desc="Tokenizing", ncols=100) as pbar:

            for path_str, items, errors in pool.imap_unordered(worker_fn, map(str, midi_files), chunksize=args.chunksize):
                try:
                    if errors:
                        n_err_files += 1
                        logging.warning("Worker reported %d errors for file: %s", len(errors), path_str)
                        if args.strict:
                            raise RuntimeError(f"Strict mode: errors in {path_str}")

                    for uid, phr_ids, phr_attn, ctx_ids, ctx_attn, meta in items:
                        writer.add_item(uid, phr_ids, phr_attn, ctx_ids, ctx_attn, meta)
                        n_items += 1
                except Exception:
                    log_exception("Main loop failed while handling worker result", path=path_str)
                finally:
                    pbar.update(1)
    finally:
        try:
            writer.close()
        except Exception:
            log_exception("Writer close failed")

    logging.info("Done. Wrote %d items into shards at %s (files with errors: %d)", n_items, args.out_dir, n_err_files)

if __name__ == "__main__":
    main()
