from dataclasses import dataclass
import math
import numpy as np

from ariautils.midi import midi_to_dict, MidiDict
import mido
import pretty_midi

from tick_ms_convert import TickMsConverter

# -----------------------------
# FAST PATH: per-file cache & MidiDict slicing
# -----------------------------

@dataclass
class FileCache:
    src_path: str
    mid: mido.MidiFile          # parsed once per file
    md_full: MidiDict           # MidiDict for entire file (from midi_to_dict)
    downbeats: np.ndarray       # seconds
    tick_ms: TickMsConverter

def build_file_cache(src_path: str) -> FileCache:
    # 1) Parse MIDI with mido (fast, in pure Python/C)
    try:
        mid = mido.MidiFile(src_path)
    except Exception:
        log_exception("mido.MidiFile load failed", path=src_path)
        raise

    # 2) Convert to MidiDict ONCE per file
    try:
        md_dict = midi_to_dict(mid)
        md_full = MidiDict.from_msg_dict(md_dict)
        md_full.remove_redundant_pedals()
        md_full.resolve_pedal() # Convert durations given pedal messages
    except Exception:
        log_exception("mido → MidiDict failed", path=src_path)
        raise

    # 3) Downbeats ONCE per file (via PrettyMIDI just for analysis)
    try:
        pm = pretty_midi.PrettyMIDI(src_path)
        downbeats = load_downbeats(pm)
    except Exception:
        log_exception("PrettyMIDI analysis failed", path=src_path)
        # Fallback: pretend 2s bar spacing for total length guessed from ticks
        # But better to re-raise; tokenizer will skip this file otherwise.
        raise

    tick_ms = TickMsConverter.from_mididict(md_full)

    return FileCache(
        src_path=src_path,
        mid=mid,
        md_full=md_full,
        downbeats=downbeats,
        tick_ms = tick_ms,
    )

def load_downbeats(pm: pretty_midi.PrettyMIDI) -> np.ndarray:
    try:
        db = pm.get_downbeats()
        if db is not None and len(db) >= 2:
            return np.asarray(db, dtype=np.float32)
    except Exception:
        log_exception("pretty_midi.get_downbeats failed")
    # Fallback 4/4 @ 120 BPM
    try:
        total = pm.get_end_time()
    except Exception:
        log_exception("pretty_midi.get_end_time failed; using 2s total")
        total = 2.0
    if total <= 0:
        return np.array([0.0, 1.0], dtype=np.float32)
    bar_sec = 2.0
    n_bars = max(2, int(math.ceil(total / bar_sec)) + 1)
    return (np.arange(n_bars, dtype=np.float32) * bar_sec)

