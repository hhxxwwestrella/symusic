from dataclasses import dataclass
import numpy as np
from typing import Iterable, Optional

# --- Tick↔ms converter that matches Aria's rounding semantics ---
@dataclass
class TickMsConverter:
    """
    Vectorized tick↔ms converter built from MidiDict tempo map.

    • Uses piecewise-linear mapping defined by tempo messages.
    • tick->ms: round once at the end (matches ariautils.midi.get_duration_ms).
    • ms->tick: round to nearest integer tick in the located segment.
    • No deepcopy; works on scalars or ndarrays.
    """
    ticks_per_beat: int
    # Segment boundaries and per-segment parameters:
    tempo_ticks: np.ndarray          # shape [S], int64, sorted, first must be 0
    tempo_us_per_beat: np.ndarray    # shape [S], int64, microseconds/beat for each segment
    ms_at_tempo_ticks: np.ndarray    # shape [S], float64, cumulative ms at each tempo tick
    ms_per_tick: np.ndarray          # shape [S], float64, ms per tick for each segment

    @staticmethod
    def _canon_tempo_msgs(tempo_msgs: Iterable[dict]) -> tuple[np.ndarray, np.ndarray]:
        """
        Sort, ensure a tempo at tick=0, and collapse duplicate ticks keeping the last.
        Returns (ticks, uspb) as int64 arrays.
        """
        # collect and sort
        tmp = [(int(m["tick"]), int(m["data"])) for m in tempo_msgs if m.get("type") == "tempo"]
        tmp.sort(key=lambda x: x[0])

        if not tmp:
            # Fallback: standard MIDI default tempo 500000 µs/beat at tick 0
            tmp = [(0, 500000)]
        # ensure a tempo at tick 0
        if tmp[0][0] != 0:
            tmp.insert(0, (0, tmp[0][1]))

        # collapse duplicate ticks (last one wins)
        out_ticks: list[int] = []
        out_uspb: list[int] = []
        i = 0
        n = len(tmp)
        while i < n:
            t = tmp[i][0]
            j = i
            # advance to last with same tick
            while j + 1 < n and tmp[j + 1][0] == t:
                j += 1
            out_ticks.append(t)
            out_uspb.append(tmp[j][1])  # keep last tempo at this tick
            i = j + 1

        return np.asarray(out_ticks, dtype=np.int64), np.asarray(out_uspb, dtype=np.int64)

    @classmethod
    def from_mididict(cls, md: "MidiDict") -> "TickMsConverter":
        ticks, uspb = cls._canon_tempo_msgs(md.tempo_msgs)

        # per-segment conversion slope: ms per tick = (us/beat)/1000 / ticks_per_beat
        ms_per_tick = (uspb.astype(np.float64) / 1000.0) / float(md.ticks_per_beat)

        # cumulative ms at each tempo boundary tick
        # ms[i] = sum_{k < i} (ticks[i]-ticks[i-1]) * ms_per_tick[i-1]
        ms_at = np.zeros_like(ticks, dtype=np.float64)
        if len(ticks) > 1:
            dticks = np.diff(ticks)  # length S-1
            # cumulative sum of previous segment durations
            ms_at[1:] = np.cumsum(dticks.astype(np.float64) * ms_per_tick[:-1])

        return cls(
            ticks_per_beat=md.ticks_per_beat,
            tempo_ticks=ticks,
            tempo_us_per_beat=uspb,
            ms_at_tempo_ticks=ms_at,
            ms_per_tick=ms_per_tick,
        )

    # --------- vectorized conversions ----------
    def _seg_index_for_ticks(self, ticks: np.ndarray) -> np.ndarray:
        # rightmost tempo boundary <= tick
        return np.searchsorted(self.tempo_ticks, ticks, side="right") - 1

    def _seg_index_for_ms(self, ms: np.ndarray) -> np.ndarray:
        # rightmost ms boundary <= ms
        return np.searchsorted(self.ms_at_tempo_ticks, ms, side="right") - 1

    def ticks_to_ms(self, ticks: np.ndarray | int) -> np.ndarray | int:
        """
        Converts absolute ticks → absolute milliseconds (int), matching Aria’s rounding:
        round once at the end (see get_duration_ms). :contentReference[oaicite:2]{index=2}
        """
        arr = np.asarray(ticks, dtype=np.int64)
        idx = self._seg_index_for_ticks(arr)
        # ms = ms_at(seg start) + (ticks - seg_start_tick) * ms_per_tick(seg)
        ms = self.ms_at_tempo_ticks[idx] + (arr - self.tempo_ticks[idx]) * self.ms_per_tick[idx]
        ms_rounded = np.rint(ms).astype(np.int64)  # round once
        return int(ms_rounded) if np.ndim(ticks) == 0 else ms_rounded

    def ms_to_tick(self, ms: np.ndarray | float | int) -> np.ndarray | int:
        """
        Converts milliseconds → absolute tick (int). We invert the same piecewise-linear
        mapping and round to nearest integer tick inside the located segment.
        """
        arr = np.asarray(ms, dtype=np.float64)
        idx = self._seg_index_for_ms(arr)
        # ticks = seg_start_tick + (ms - ms_at(seg start)) / ms_per_tick(seg)
        ticks = self.tempo_ticks[idx] + (arr - self.ms_at_tempo_ticks[idx]) / self.ms_per_tick[idx]
        ticks_rounded = np.rint(ticks).astype(np.int64)
        return int(ticks_rounded) if np.ndim(ms) == 0 else ticks_rounded

    # --------- helpers for slicing ----------
    def tempo_at_tick(self, tick: int) -> int:
        """Tempo (µs/beat) active at absolute tick."""
        i = int(np.searchsorted(self.tempo_ticks, int(tick), side="right") - 1)
        return int(self.tempo_us_per_beat[max(i, 0)])

    def slice_tempo_msgs(self, start_tick_abs: int, end_tick_abs: int) -> list[dict]:
        """
        Tempo map for a slice rebased so that `start_tick_abs` → 0.
        Always includes a tempo event at tick 0, then any changes strictly inside the window.
        """
        # tempo at slice start
        start_tempo = self.tempo_at_tick(start_tick_abs)
        out = [{"type": "tempo", "data": int(start_tempo), "tick": 0}]

        # find tempo change ticks inside (start, end)
        t = self.tempo_ticks
        u = self.tempo_us_per_beat
        mask = (t > start_tick_abs) & (t < end_tick_abs)
        if np.any(mask):
            for tt, uu in zip(t[mask], u[mask]):
                out.append({"type": "tempo", "data": int(uu), "tick": int(tt - start_tick_abs)})
        return out
